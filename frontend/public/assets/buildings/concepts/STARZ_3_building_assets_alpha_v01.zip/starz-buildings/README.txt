STARZ 3.0 - Building concept sprites, alpha v0.1

Four concept assets, each 224x224 PNG RGBA with transparent background.
Also includes WebP versions and a preview contact sheet.

Mapping:
- ferrite_extractor: Extrator de ferrita
- civil_district: Distrito civil
- planetary_research_center: Centro de Pesquisa Planetario
- orbital_shipyard: Estaleiro orbital

Art direction: isometric 3/4 sci-fi pixel art, gunmetal industrial forms,
cyan lighting, amber highlights. These are prototypes pending approval.

The GitHub branch art/building-assets-alpha-v1 includes a tiny WebP atlas
preview for Codex: frontend/public/assets/buildings/concepts/.
No gameplay or frontend code was changed.
